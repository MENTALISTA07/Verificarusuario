# Verificarusuario

wget https://raw.githubusercontent.com/flindao/Verificarusuario/master/checkduration.php && mv -f $HOME/checkduration.php /var/www/html/checkduration.php && chmod 777 /var/www/html/checkduration.php
